package com.mainGroup.CINEMAv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemAv2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
