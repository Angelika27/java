package com.mainGroup.CINEMAv2.repo;

import com.mainGroup.CINEMAv2.model.Cinema;
import org.springframework.data.repository.CrudRepository;

public interface CinemaRepository extends CrudRepository<Cinema, Long> {
}
