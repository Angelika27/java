package com.mainGroup.CINEMAv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemAv2Application {

	public static void main(String[] args) {
		SpringApplication.run(CinemAv2Application.class, args);
	}

}
