package com.mainGroup.CINEMAv2.repo;

import com.mainGroup.CINEMAv2.model.Hall;
import org.springframework.data.repository.CrudRepository;

public interface HallRepository extends CrudRepository<Hall, Long> {
}
